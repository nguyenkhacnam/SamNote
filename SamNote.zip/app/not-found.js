import React from 'react'

const NotFound = () => {
  return (
    <div>Lỗi</div>
  )
}

export default NotFound;